  <header class="header-section">
      <div class="logo">
          <a href="./index.php">
              <img src="img/logo.png" width="300" alt="">
          </a>
      </div>
      <div class="container">

          <div class="nav-menu">
              <nav class="mainmenu mobile-menu">
                  <ul>
                      <!-- <li class="active"><a href="./index.php">Home</a></li> -->
                      <li><a href="index.php#about">About Us</a></li>
                      <li><a href="committee.php">COMMITTEE</a>
                      </li>
                      <li><a href="call-for-papper.php">CALL FOR PAPER</a>
                      <li><a href="index.php#imp_dates">IMPORTANT DATES</a></li>
                      <!-- <li><a href="./blog.html">Blog</a></li> -->
                      <li><a href="index.php#registration">REGISTRATIONS</a></li>
                  </ul>
              </nav>
              <!-- <a href="#" class="primary-btn top-btn"><i class="fa fa-ticket"></i> Register</a> -->
          </div>
          <div id="mobile-menu-wrap"></div>
      </div>
  </header>