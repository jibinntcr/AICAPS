<footer class="footer-section">
    <div class="container">
        <!-- <div class="partner-logo owl-carousel">
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-1.png" alt="">
                </div>
            </a>
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-2.png" alt="">
                </div>
            </a>
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-3.png" alt="">
                </div>
            </a>
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-4.png" alt="">
                </div>
            </a>
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-5.png" alt="">
                </div>
            </a>
            <a href="#" class="pl-table">
                <div class="pl-tablecell">
                    <img src="img/partner-logo/logo-6.png" alt="">
                </div>
            </a>
        </div> -->
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-text">
                    <!-- <div class="ft-logo">
                        <a href="#" class="footer-logo"><img src="img/logo.png"width="200" alt=""></a>
                    </div> -->
                    <ul>
                    <li><a href="index.html#about">ABOUT US</a></li>
                      <li><a href="committee.html">COMMITTEE</a>
                      </li>
                      <li><a href="call-for-papper.html">CALL FOR PAPER</a>
                      <li><a href="index.html#imp_dates">IMPORTANT DATES</a></li>
                      <!-- <li><a href="./blog.html">Blog</a></li> -->
                      <li><a href="index.html#registration">REGISTRATIONS</a></li>
                    </ul>
                    <div class="copyright-text">
                        <p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script> All rights reserved | This
                            site is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="http://infinio.co.in/" target="_blank">infinio</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                    <div class="ft-social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>